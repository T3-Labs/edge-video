module edge-video-v2

go 1.21

require (
	github.com/rabbitmq/amqp091-go v1.10.0
	gopkg.in/yaml.v3 v3.0.1
)
